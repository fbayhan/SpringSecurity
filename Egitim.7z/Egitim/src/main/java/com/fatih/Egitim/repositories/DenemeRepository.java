package com.fatih.Egitim.repositories;

import com.fatih.Egitim.models.Deneme;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DenemeRepository extends JpaRepository<Deneme, Long> {

    Deneme findById(long id);

}

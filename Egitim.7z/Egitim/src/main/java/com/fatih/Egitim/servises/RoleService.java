package com.fatih.Egitim.servises;

import com.fatih.Egitim.models.Roles;
import com.fatih.Egitim.repositories.RoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.management.relation.Role;

@Service
@Transactional
public class RoleService {

    @Autowired
    RoleRepository roleRepository;

    public Roles newRole() {
        Roles roleAdmin = new Roles();
        roleAdmin.setRoleName("ADMIN");
        roleRepository.save(roleAdmin);
        Roles roleUser = new Roles();
        roleUser.setRoleName("USER");
        roleRepository.save(roleUser);
        return roleUser;
    }

}
